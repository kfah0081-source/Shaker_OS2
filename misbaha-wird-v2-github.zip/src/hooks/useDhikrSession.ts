import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { active, freqAt, persistenceAt } from '@/lib/model'
import { BASE, DONE, KINDS, load, save, type Profile, type Session } from '@/lib/store'

export type TracePoint = { t: number; f: number }
export type Dhikr = Profile
const IDLE_MS = 30000

export function useDhikrSession() {
  const [running, setRunning] = useState(false)
  const [elapsedSec, setElapsedSec] = useState(0)
  const [count, setCount] = useState(0)
  const [rounds, setRounds] = useState(0)
  const [total, setTotal] = useState(0)
  const [trace, setTrace] = useState<TracePoint[]>([])
  const [pulse, setPulse] = useState(0)
  const [rhythm, setRhythm] = useState({ avg: 0, reg: 0 })
  const gaps = useRef<number[]>([])
  const lastReal = useRef(0)
  const [customs, setCustoms] = useState<Profile[]>(() => load('customs', []))
  const [sessions, setSessions] = useState<Session[]>(() => load('sessions', []))
  const [goal, setGoalS] = useState<number>(() => load('goal', 30))
  const [targets, setTargets] = useState<Record<string, number>>(() => load('targets', {}))
  const [dhikrId, setDhikrId] = useState<string>(() => load('last', BASE[0].id))

  const adhkar = [...BASE, ...customs].map((d) => ({ ...d, target: targets[d.id] ?? d.target }))
  const dhikr = adhkar.find((d) => d.id === dhikrId) ?? adhkar[0]
  active.fTheta = dhikr.fTheta
  active.tMid = dhikr.tMid

  const accRef = useRef(0)
  const stampRef = useRef<number | null>(null)
  const lastTap = useRef(0)
  const done = useRef(false)
  const flags = useRef([false, false, false])
  const dhikrRef = useRef(dhikr)
  const totalRef = useRef(total)
  const goalRef = useRef(goal)
  const countRef = useRef(count)
  countRef.current = count
  dhikrRef.current = dhikr
  totalRef.current = total
  goalRef.current = goal

  const getElapsed = useCallback(() => {
    if (stampRef.current == null) return accRef.current
    return accRef.current + (performance.now() - stampRef.current) / 1000
  }, [])

  const fresh = useCallback(() => {
    accRef.current = 0
    stampRef.current = null
    done.current = false
    flags.current = [false, false, false]
    setRunning(false)
    setElapsedSec(0)
    setTotal(0)
    setTrace([])
    gaps.current = []
    lastReal.current = 0
    setRhythm({ avg: 0, reg: 0 })
  }, [])

  // حفظ الجلسة في السجل
  const commit = useCallback(() => {
    const e = getElapsed()
    if (done.current || e < 5) return
    done.current = true
    const m = e / 60
    let s = 0, n = 0
    for (let t = 0; t <= m; t += 0.25) { s += freqAt(t); n++ }
    const rec: Session = { ts: Date.now(), id: dhikrRef.current.id, sec: e, count: totalRef.current, eff: persistenceAt(m), avgF: s / n }
    setSessions((p) => { const x = [...p, rec].slice(-500); save('sessions', x); return x })
  }, [getElapsed])

  const start = useCallback(() => {
    if (stampRef.current != null) return
    if (done.current) fresh()
    lastTap.current = performance.now()
    stampRef.current = performance.now()
    setRunning(true)
  }, [fresh])

  const pause = useCallback(() => {
    if (stampRef.current == null) return
    accRef.current = getElapsed()
    stampRef.current = null
    setRunning(false)
  }, [getElapsed])

  const reset = useCallback(() => {
    pause()
    commit()
    fresh()
    setCount(0)
    setRounds(0)
  }, [pause, commit, fresh])

  const tap = useCallback(() => {
    if (done.current) fresh()
    const now = performance.now()
    if (lastReal.current && now - lastReal.current < IDLE_MS) {
      gaps.current = [...gaps.current, (now - lastReal.current) / 1000].slice(-20)
      const g = gaps.current
      const avg = g.reduce((a, b) => a + b, 0) / g.length
      const sd = Math.sqrt(g.reduce((a, b) => a + (b - avg) ** 2, 0) / g.length)
      setRhythm({ avg, reg: Math.round(100 * Math.max(0, 1 - sd / avg)) })
    }
    lastReal.current = now
    lastTap.current = now
    if (stampRef.current == null) {
      stampRef.current = performance.now()
      setRunning(true)
    }
    if (countRef.current + 1 >= dhikrRef.current.target) {
      toast(DONE[dhikrRef.current.id] ?? 'بلغتَ غايتك من هذا الذكر، تقبّل الله منك')
      navigator.vibrate?.(60)
    }
    setPulse((p) => p + 1)
    setTotal((t) => t + 1)
    setCount((c) => {
      if (c + 1 >= dhikrRef.current.target) { setRounds((r) => r + 1); return 0 }
      return c + 1
    })
  }, [fresh])

  const undo = () => {
    if (totalRef.current <= 0) return
    setTotal((t) => Math.max(0, t - 1))
    setCount((c) => {
      if (c > 0) return c - 1
      setRounds((r) => Math.max(0, r - 1))
      return Math.max(0, dhikrRef.current.target - 1)
    })
  }
  const addManual = (id: string, n: number, min: number, ts: number, mode: 'whisper' | 'loud') => {
    const d = adhkar.find((x) => x.id === id) ?? adhkar[0]
    const keep = [active.fTheta, active.tMid]
    active.fTheta = d.fTheta; active.tMid = d.tMid
    let s = 0, k = 0
    for (let t = 0; t <= min; t += 0.25) { s += freqAt(t); k++ }
    const rec: Session = { ts, id: d.id, sec: min * 60, count: n, eff: persistenceAt(min), avgF: s / k, mode, manual: true }
    active.fTheta = keep[0]; active.tMid = keep[1]
    setSessions((p) => { const x = [...p, rec].slice(-500); save('sessions', x); return x })
  }

  const selectDhikr = useCallback((id: string) => {
    pause(); commit(); fresh()
    setDhikrId(id); save('last', id)
    setCount(0); setRounds(0)
  }, [pause, commit, fresh])

  const setTarget = (id: string, n: number) =>
    setTargets((p) => { const x = { ...p, [id]: n }; save('targets', x); return x })
  const setGoal = (n: number) => { setGoalS(n); save('goal', n) }
  const addCustom = (text: string, target: number, kind: keyof typeof KINDS, meaning = 'ذكر مخصّص', mode: 'whisper' | 'loud' = 'loud') => {
    const k = KINDS[kind]
    const p: Profile = { id: 'c' + Date.now(), text, target, meaning, effect: k.effect, fTheta: k.fTheta, tMid: k.tMid, custom: true, mode }
    setCustoms((c) => { const x = [...c, p]; save('customs', x); return x })
    setDhikrId(p.id)
  }

  useEffect(() => {
    const iv = window.setInterval(() => {
      const e = getElapsed()
      setElapsedSec(e)
      if (stampRef.current == null) return
      // إيقاف تلقائي بعد 30 ثانية دون ذكر، وخصم مدة الخمول
      if (performance.now() - lastTap.current > IDLE_MS) {
        accRef.current = Math.max(0, e - IDLE_MS / 1000)
        stampRef.current = null
        setRunning(false)
        setElapsedSec(accRef.current)
        commit()
        toast('توقف العداد تلقائياً بعد 30 ثانية دون ذكر')
        return
      }
      const tMin = e / 60
      setTrace((tr) => {
        const last = tr[tr.length - 1]
        if (last && Math.abs(last.t - tMin) < 1 / 240) return tr
        const next = [...tr, { t: tMin, f: freqAt(tMin) }]
        return next.length > 7200 ? next.slice(-7200) : next
      })
      const eff = persistenceAt(tMin)
      const marks: [number, string][] = [[0.5, 'بلغت نصف الأثر المستهدف'], [0.9, 'اقتربت من اكتمال الأثر المستهدف'], [1, 'اكتمل الأثر المستهدف 🎉']]
      marks.forEach(([r, msg], i) => {
        if (!flags.current[i] && eff >= goalRef.current * r) {
          flags.current[i] = true
          toast(msg)
          navigator.vibrate?.(200)
        }
      })
    }, 250)
    return () => window.clearInterval(iv)
  }, [getElapsed, commit])

  return { running, elapsedSec, getElapsed, count, rounds, total, dhikr, adhkar, trace, pulse, sessions, goal, start, pause, reset, tap, undo, addManual, rhythm, selectDhikr, setTarget, setGoal, addCustom }
}
