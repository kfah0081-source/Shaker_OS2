import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  BarChart3,
  Check,
  ChevronLeft,
  Clock3,
  Flame,
  Hand,
  Heart,
  History,
  Moon,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Settings2,
  Sparkles,
  Target,
  TimerReset,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react'
import { useDhikrSession } from '@/hooks/useDhikrSession'
import { load, save, type Session } from '@/lib/store'

const fmt = (value: number) => new Intl.NumberFormat('ar-SA').format(Math.round(value))
const fmtTime = (sec: number) => {
  const m = Math.floor(sec / 60).toString().padStart(2, '0')
  const s = Math.floor(sec % 60).toString().padStart(2, '0')
  return `${m}:${s}`
}

function Metric({ icon: Icon, label, value, accent = 'gold' }: { icon: typeof Flame; label: string; value: string; accent?: 'gold' | 'mint' | 'violet' }) {
  return (
    <div className={`metric metric-${accent}`}>
      <div className="metric-icon"><Icon size={16} /></div>
      <div><div className="metric-label">{label}</div><div className="metric-value">{value}</div></div>
    </div>
  )
}

export default function Home() {
  const s = useDhikrSession()
  const [tab, setTab] = useState<'home' | 'insights' | 'settings'>('home')
  const [sound, setSound] = useState(() => load('sound', true))
  const [showPicker, setShowPicker] = useState(false)
  const [showQuick, setShowQuick] = useState(false)
  const [dailyIntent, setDailyIntent] = useState(() => load('dailyIntent', 'حضور القلب قبل كثرة العدد'))
  const [theme, setTheme] = useState(() => load('theme', ''))

  useEffect(() => { document.documentElement.dataset.theme = theme; save('theme', theme) }, [theme])
  useEffect(() => { save('sound', sound) }, [sound])
  useEffect(() => { save('dailyIntent', dailyIntent) }, [dailyIntent])

  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0)
  const todayLabel = new Intl.DateTimeFormat('ar-SA', { weekday: 'long', day: 'numeric', month: 'long' }).format(todayStart)
  const todayStartMs = todayStart.getTime()
  const todaySessions = useMemo(() => s.sessions.filter((x: Session) => x.ts >= todayStartMs), [s.sessions, todayStartMs])
  const todayCount = todaySessions.reduce((n: number, x: Session) => n + x.count, s.total)
  const todayMinutes = todaySessions.reduce((n: number, x: Session) => n + x.sec / 60, 0) + s.elapsedSec / 60
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (6 - i))
    const next = new Date(d); next.setDate(next.getDate() + 1)
    return { label: d.toLocaleDateString('ar-SA', { weekday: 'short' }).replace('،', ''), count: s.sessions.filter((x: Session) => x.ts >= d.getTime() && x.ts < next.getTime()).reduce((n: number, x: Session) => n + x.count, 0) }
  })
  const maxDay = Math.max(1, ...weekDays.map((x) => x.count))
  const progress = Math.min(100, (s.count / Math.max(1, s.dhikr.target)) * 100)

  const tap = () => {
    s.tap()
    if (sound && typeof window !== 'undefined') {
      try { const Ctx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext; if (Ctx) { const ctx = new Ctx(); const o = ctx.createOscillator(); const g = ctx.createGain(); o.frequency.value = 520; g.gain.setValueAtTime(0.025, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08); o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.08) } } catch { /* audio is optional */ }
    }
  }
  const reset = () => { s.reset(); setShowPicker(false) }

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <div className="brand"><div className="brand-mark"><Sparkles size={18} /></div><div><div className="brand-name">وِرد</div><div className="brand-sub">مساحة للذكر</div></div></div>
        <div className="top-actions"><button className="icon-btn" onClick={() => setSound(!sound)} aria-label="الصوت">{sound ? <Volume2 size={18} /> : <VolumeX size={18} />}</button><button className="icon-btn" onClick={() => setTab('settings')} aria-label="الإعدادات"><Settings2 size={18} /></button></div>
      </header>

      <main className="main-content">
        {tab === 'home' && <>
          <section className="welcome-row"><div><p className="eyebrow">{todayLabel}</p><h1>أهلاً بك في <span>وِردك.</span></h1><p className="muted">خطوة واحدة الآن، وأثرٌ يرافقك طوال اليوم.</p></div><div className="streak-badge"><Flame size={18} fill="currentColor" /><strong>{fmt(Math.max(1, Math.min(7, todaySessions.length + (todayCount > 0 ? 1 : 0))))}</strong><small>أيام حضور</small></div></section>

          <section className="intention-card"><div className="intention-icon"><Heart size={17} fill="currentColor" /></div><div className="intention-copy"><span>نية اليوم</span><input value={dailyIntent} onChange={(e) => setDailyIntent(e.target.value)} aria-label="نية اليوم" /></div><ChevronLeft size={18} className="muted-icon" /></section>

          <section className="focus-grid">
            <div className="counter-card">
              <div className="counter-head"><button className="dhikr-name" onClick={() => setShowPicker(true)}>{s.dhikr.text}<ChevronLeft size={16} /></button><span className="live-pill"><i /> {s.running ? 'جلسة نشطة' : 'جاهز للسكينة'}</span></div>
              <div className="counter-stage">
                <div className="ring ring-back"><svg viewBox="0 0 240 240"><circle cx="120" cy="120" r="102" /><circle className="ring-progress" cx="120" cy="120" r="102" style={{ strokeDashoffset: 641 - (641 * progress / 100) }} /></svg></div>
                <button className={`tap-orb ${s.running ? 'is-running' : ''}`} onClick={tap} aria-label="سبّح"><div className="orb-glow" /><span className="orb-number">{fmt(s.count)}</span><span className="orb-label">من {fmt(s.dhikr.target)}</span><span className="orb-hint">اضغط للذكر</span></button>
              </div>
              <div className="counter-footer"><button className="text-btn" onClick={() => s.undo()}><RotateCcw size={14} /> تراجع</button><div className="round-count"><span>الدورات</span><strong>{fmt(s.rounds)}</strong></div><button className="text-btn" onClick={reset}><TimerReset size={14} /> جلسة جديدة</button></div>
            </div>
            <div className="side-column">
              <div className="session-card"><div className="card-title"><span>إيقاع الجلسة</span><Activity size={17} /></div><div className="session-time">{fmtTime(s.elapsedSec)}</div><div className="session-status">{s.running ? 'استمر على هذا النسق الهادئ' : 'ابدأ حين يحضر قلبك'}</div><div className="session-actions"><button className="primary-btn" onClick={s.running ? s.pause : s.start}>{s.running ? <Pause size={16} /> : <Play size={16} fill="currentColor" />} {s.running ? 'إيقاف مؤقت' : 'بدء الجلسة'}</button><button className="secondary-btn" onClick={() => setShowQuick(true)}><Zap size={16} /> ورد سريع</button></div></div>
              <div className="metrics-grid"><Metric icon={Target} label="الهدف اليومي" value={`${fmt(Math.max(todayCount, s.total))} / ${fmt(s.goal)}`} /><Metric icon={Clock3} label="وقت الذكر" value={`${fmt(todayMinutes)} د`} accent="mint" /><Metric icon={Sparkles} label="الانتظام" value={`${fmt(s.rhythm.reg)}%`} accent="violet" /></div>
            </div>
          </section>

          <section className="section-block"><div className="section-heading"><div><p className="eyebrow">استمرارية هادئة</p><h2>أثر هذا الأسبوع</h2></div><button className="link-btn" onClick={() => setTab('insights')}>كل الإحصاءات <ChevronLeft size={15} /></button></div><div className="week-chart">{weekDays.map((day) => <div className="day-bar" key={day.label}><span>{day.count ? fmt(day.count) : ''}</span><div className="bar-track"><div className="bar-fill" style={{ height: `${Math.max(8, (day.count / maxDay) * 100)}%` }} /></div><small>{day.label}</small></div>)}</div></section>

          <section className="lower-grid"><div className="quote-card"><div className="quote-mark">“</div><p>وَاذْكُر رَّبَّكَ إِذَا نَسِيتَ</p><span>الكهف · ٢٤</span></div><div className="recent-card"><div className="section-heading"><h3>آخر جلسة</h3><History size={17} /></div>{s.sessions.length ? <div className="recent-row"><div className="recent-avatar"><Hand size={16} /></div><div><strong>{s.sessions.at(-1)?.id === s.dhikr.id ? s.dhikr.text : 'جلسة ذكر'}</strong><span>{fmtTime(s.sessions.at(-1)?.sec || 0)} · {fmt(s.sessions.at(-1)?.count || 0)} تسبيحة</span></div><Check size={18} className="success-icon" /></div> : <p className="muted">ستظهر جلساتك هنا بعد أول ورد.</p>}</div></section>
        </>}

        {tab === 'insights' && <section className="page-panel"><div className="page-title"><p className="eyebrow">نظرة شاملة</p><h1>رحلتك مع الذكر</h1><p className="muted">بياناتك تبقى على جهازك وتساعدك على ملاحظة الاستمرارية، لا على مطاردة الأرقام.</p></div><div className="metrics-grid metrics-large"><Metric icon={Flame} label="إجمالي التسبيحات" value={fmt(s.sessions.reduce((n: number, x: Session) => n + x.count, 0) + s.total)} /><Metric icon={Clock3} label="إجمالي الدقائق" value={fmt(s.sessions.reduce((n: number, x: Session) => n + x.sec / 60, 0) + s.elapsedSec / 60)} accent="mint" /><Metric icon={BarChart3} label="الجلسات المسجلة" value={fmt(s.sessions.length)} accent="violet" /></div><div className="insight-note"><Sparkles size={18} /><p><strong>اقتراح وِرد:</strong> جرّب جلسة من {fmt(s.goal)} دقيقة غداً، ثم راقب حضورك لا سرعتك.</p></div></section>}

        {tab === 'settings' && <section className="page-panel"><div className="page-title"><p className="eyebrow">تخصيص التجربة</p><h1>إعدادات وِرد</h1><p className="muted">كل شيء مصمم ليختفي عندما تبدأ الذكر.</p></div><div className="settings-list"><div className="setting-row"><div><strong>المظهر</strong><span>اختر الحالة البصرية التي تناسب وقتك</span></div><select value={theme} onChange={(e) => setTheme(e.target.value)}><option value="">ليلي دافئ</option><option value="calm">سكينة</option><option value="lead">ليلة بنفسجية</option></select></div><div className="setting-row"><div><strong>الهدف اليومي</strong><span>الدقائق التي ترغب في حضورها كل يوم</span></div><input className="number-input" type="number" min="1" max="240" value={s.goal} onChange={(e) => s.setGoal(Number(e.target.value) || 1)} /></div><div className="setting-row"><div><strong>الصوت الهادئ</strong><span>نقرة لطيفة مع كل تسبيحة</span></div><button className={`switch ${sound ? 'on' : ''}`} onClick={() => setSound(!sound)}><span /></button></div></div><div className="privacy-note"><Moon size={18} /><span>خصوصيتك أولاً: لا حساب، لا إعلانات، ولا رفع لسجل الذكر. البيانات محفوظة محلياً.</span></div></section>}
      </main>

      <nav className="bottom-nav"><button className={tab === 'home' ? 'active' : ''} onClick={() => setTab('home')}><Hand size={19} /><span>الذكر</span></button><button className={tab === 'insights' ? 'active' : ''} onClick={() => setTab('insights')}><BarChart3 size={19} /><span>رحلتي</span></button><button className="nav-center" onClick={() => { setTab('home'); setShowQuick(true) }}><Plus size={22} /></button><button onClick={() => setShowQuick(true)}><Clock3 size={19} /><span>أوراد</span></button><button className={tab === 'settings' ? 'active' : ''} onClick={() => setTab('settings')}><Settings2 size={19} /><span>المزيد</span></button></nav>

      {showPicker && <div className="modal-layer" onClick={() => setShowPicker(false)}><div className="sheet" onClick={(e) => e.stopPropagation()}><div className="sheet-head"><h2>اختر الذكر</h2><button className="icon-btn" onClick={() => setShowPicker(false)}><X size={18} /></button></div>{s.adhkar.map((d) => <button className={`dhikr-option ${d.id === s.dhikr.id ? 'selected' : ''}`} key={d.id} onClick={() => { s.selectDhikr(d.id); setShowPicker(false) }}><div><strong>{d.text}</strong><span>{d.meaning}</span></div>{d.id === s.dhikr.id && <Check size={18} />}</button>)}</div></div>}
      {showQuick && <div className="modal-layer" onClick={() => setShowQuick(false)}><div className="sheet quick-sheet" onClick={(e) => e.stopPropagation()}><div className="sheet-head"><div><p className="eyebrow">اختر إيقاعك</p><h2>ورد سريع</h2></div><button className="icon-btn" onClick={() => setShowQuick(false)}><X size={18} /></button></div><p className="muted">جلسة جاهزة لتبدأ بلا تفكير كثير.</p><div className="quick-grid">{[{ n: 'دقيقة حضور', d: 1 }, { n: '٥ دقائق', d: 5 }, { n: '١٠ دقائق', d: 10 }].map((x) => <button key={x.d} className="quick-option" onClick={() => { s.setGoal(x.d); setShowQuick(false); s.start() }}><Clock3 size={18} /><strong>{x.n}</strong><span>ابدأ الآن</span></button>)}</div></div></div>}
    </div>
  )
}
