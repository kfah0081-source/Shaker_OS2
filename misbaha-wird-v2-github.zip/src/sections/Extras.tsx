import { useEffect, useState } from 'react'
import type { Dhikr } from '@/hooks/useDhikrSession'
import { arNum, manual } from '@/lib/model'
import { KINDS, THEMES, load, save, stats, type Session } from '@/lib/store'

type Props = {
  adhkar: Dhikr[]
  sessions: Session[]
  goal: number
  onGoal: (n: number) => void
  onCap: () => void
  view: 'settings' | 'stats'
  onAdd: (text: string, target: number, kind: keyof typeof KINDS, meaning?: string, mode?: 'whisper' | 'loud') => void
}

export default function Extras({ adhkar, sessions, goal, onGoal, onAdd, onCap, view }: Props) {
  const [cap, setCap] = useState<{ on: boolean; rules: [number, number][] }>(() => ({ on: manual.on, rules: manual.rules }))
  const [rm, setRm] = useState(23)
  const [re, setRe] = useState(1440)
  const putCap = (n: { on: boolean; rules: [number, number][] }) => { manual.on = n.on; manual.rules = n.rules; setCap(n); save('cap', n); try { localStorage.setItem('msb:cap', JSON.stringify(n)) } catch { /* ignore */ } onCap() }
  const [theme, setTheme] = useState<string>(() => load('theme', ''))
  const [text, setText] = useState('')
  const [tg, setTg] = useState(33)
  const [meaning, setMeaning] = useState('')
  const [mode, setMode] = useState<'whisper' | 'loud'>('loud')
  const [kind, setKind] = useState<keyof typeof KINDS>('soft')
  useEffect(() => { document.documentElement.dataset.theme = theme; save('theme', theme) }, [theme])

  const box = 'flex min-w-0 flex-col gap-3 rounded-xl border hairline p-5'
  const inp = 'min-w-0 rounded-lg border hairline bg-transparent px-3 py-2 text-sm text-[--ink] outline-none'
  const h = 'font-display text-xl text-[#d4b67e]'
  const rows: [string, number][] = [['اليوم', 1], ['الأسبوع', 7], ['الشهر', 30]]

  return (
    <section className="grid grid-cols-1 gap-6 py-12 md:grid-cols-2">
      <div className={box + (view === 'stats' ? ' hidden' : '')}>
        <h3 className={h}>المظهر</h3>
        <div className="flex flex-wrap gap-2">
          {THEMES.map(([k, l]) => (
            <button key={k} onClick={() => setTheme(k)} className={`rounded-full border px-4 py-1.5 text-sm ${theme === k ? 'border-[#d4b67e]/70 text-[#fce1b6]' : 'hairline text-[--ink-dim]'}`}>{l}</button>
          ))}
        </div>
        <h3 className={h + ' mt-3'}>هدف الأثر والتذكيرات</h3>
        <label className="flex items-center gap-3 text-sm text-[--ink-dim]">
          الأثر المستهدف (دقيقة)
          <input type="number" min={5} max={45} value={goal} onChange={(e) => onGoal(Math.min(1440, Math.max(5, +e.target.value || 5)))} className={inp + ' w-20'} />
        </label>
        <p className="text-xs text-[--ink-faint]">تنبيه عند بلوغ 50% ثم 90% ثم اكتمال الأثر المستهدف.</p>
      </div>

      <div className={box + (view === 'stats' ? ' hidden' : '')}>
        <h3 className={h}>سقف الأثر اليدوي</h3>
        <label className="flex items-center gap-2 text-sm text-[--ink-dim]"><input type="checkbox" checked={cap.on} onChange={() => putCap({ ...cap, on: !cap.on })} />استخدام سقفي الخاص بدل نموذج التطبيق</label>
        {cap.rules.length === 0 && <p className="text-xs text-[--ink-faint]">لا توجد قواعد بعد. القاعدة: عند ذكر لمدة X دقيقة يدوم الأثر Y دقيقة.</p>}
        {[...cap.rules].sort((a, b) => a[0] - b[0]).map(([a, b]) => (
          <div key={a} className="flex items-center justify-between gap-2 text-sm text-[--ink-dim]">
            <span className="tabular-nums">{arNum(a)} د ← {arNum(b)} د {b >= 60 ? `(${arNum(+(b / 60).toFixed(1))} ساعة)` : ''}</span>
            <button onClick={() => putCap({ ...cap, rules: cap.rules.filter((r) => r[0] !== a) })} className="text-[--ink-faint]">✕</button>
          </div>
        ))}
        <div className="flex items-center gap-2 text-xs text-[--ink-dim]">
          ذكر <input type="number" min={1} value={rm} onChange={(e) => setRm(Math.max(1, +e.target.value || 1))} className={inp + ' w-20'} /> د ← أثر <input type="number" min={1} value={re} onChange={(e) => setRe(Math.max(1, +e.target.value || 1))} className={inp + ' w-24'} /> د
        </div>
        <button onClick={() => putCap({ ...cap, rules: [...cap.rules.filter((r) => r[0] !== rm), [rm, re]] })} className="rounded-lg border border-[#d4b67e]/60 py-2 text-sm text-[#fce1b6]">إضافة قاعدة</button>
        <p className="text-xs leading-relaxed text-[--ink-faint]">بين القاعدتين يتدرج الأثر خطيًا، وبعد آخر قاعدة يثبت عند قيمتها. هذا تقدير شخصي تحدده أنت، وليس نتيجة النموذج ولا قياسًا طبيًا.</p>
      </div>

      <div className={box + (view === 'stats' ? ' hidden' : '')}>
        <h3 className={h}>إضافة ذكر</h3>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="نص الذكر" className={inp} />
        <input value={meaning} onChange={(e) => setMeaning(e.target.value)} placeholder="معنى الذكر (اختياري)" className={inp} />
        <select value={mode} onChange={(e) => setMode(e.target.value as 'whisper' | 'loud')} className={inp + ' w-full bg-[#101e2c]'}>
          <option value="loud">جهرًا</option><option value="whisper">همسًا</option>
        </select>
        <div className="flex gap-3">
          <input type="number" min={1} value={tg} onChange={(e) => setTg(Math.max(1, +e.target.value || 1))} className={inp + ' w-24'} />
          <select value={kind} onChange={(e) => setKind(e.target.value as keyof typeof KINDS)} className={inp + ' flex-1 bg-[#101e2c]'}>
            {Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v.l} (≈{v.fTheta} Hz)</option>)}
          </select>
        </div>
        <button onClick={() => { if (text.trim()) { onAdd(text.trim(), tg, kind, meaning.trim() || undefined, mode); setText(''); setMeaning('') } }} className="rounded-lg border border-[#d4b67e]/60 py-2 text-sm text-[#fce1b6]">إضافة</button>
      </div>

      <div className={box + (view === 'settings' ? ' hidden' : '')}>
        <h3 className={h}>الاستقرار والمتوسط</h3>
        {rows.map(([l, d]) => {
          const s = stats(sessions, d)
          return (
            <div key={l} className="flex justify-between text-sm text-[--ink-dim]">
              <span>{l}</span>
              <span className="tabular-nums">{arNum(+s.min.toFixed(1))} د · {s.avgF ? arNum(+s.avgF.toFixed(1)) : '-'} هرتز · {arNum(s.consistency)}٪</span>
            </div>
          )
        })}
        <p className="text-xs text-[--ink-faint]">الاستقرار = نسبة الأيام النشطة، والتردد متوسط مرجّح بالزمن.</p>
      </div>

      <div className={box + (view === 'settings' ? ' hidden' : '')}>
        <h3 className={h}>آخر جلسة لكل ذكر</h3>
        {adhkar.map((d) => {
          const l = [...sessions].reverse().find((s) => s.id === d.id)
          return (
            <div key={d.id} className="flex justify-between gap-3 text-sm text-[--ink-dim]">
              <span>{d.text}</span>
              <span className="tabular-nums">{l ? `${arNum(+l.eff.toFixed(1))} / ${arNum(goal)} د (${arNum(Math.round((l.eff / goal) * 100))}٪) · ${new Date(l.ts).toLocaleDateString('ar')}` : '-'}</span>
            </div>
          )
        })}
      </div>
    </section>
  )
}
