import { useEffect, useRef, useState } from 'react'
import type { Dhikr } from '@/hooks/useDhikrSession'
import { arNum } from '@/lib/model'

type Props = {
  dhikr: Dhikr
  count: number
  rounds: number
  onTap: () => void
  onSelect: (id: string) => void
  adhkar: Dhikr[]
  onTarget: (n: number) => void
}

const R = 118
const CIRC = 2 * Math.PI * R

export default function DhikrCounter({ dhikr, count, rounds, onTap, onSelect, adhkar, onTarget }: Props) {
  const [ripples, setRipples] = useState<number[]>([])
  const idRef = useRef(0)

  const progress = count / dhikr.target

  const fire = () => {
    onTap()
    const id = ++idRef.current
    setRipples((r) => [...r.slice(-4), id])
  }

  useEffect(() => {
    if (!ripples.length) return
    const t = window.setTimeout(() => setRipples((r) => r.slice(1)), 750)
    return () => window.clearTimeout(t)
  }, [ripples])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        const tag = (e.target as HTMLElement)?.tagName
        if (tag === 'BUTTON' || tag === 'INPUT') return
        e.preventDefault()
        fire()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onTap])

  return (
    <section className="flex flex-col items-center gap-8">
      {/* اختيار الذكر */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {adhkar.map((d) => {
          const active = d.id === dhikr.id
          return (
            <button
              key={d.id}
              onClick={() => onSelect(d.id)}
              className={`max-w-full rounded-full border px-3 py-1.5 text-center text-xs transition-all sm:px-4 sm:text-sm duration-300 ${
                active
                  ? 'border-[#d4b67e]/70 bg-[#d4b67e]/10 text-[#fce1b6]'
                  : 'hairline text-[--ink-dim] hover:border-[#d4b67e]/40 hover:text-[#fce1b6]'
              }`}
            >
              {d.text}
            </button>
          )
        })}
      </div>

      <p className="-mt-4 text-center text-xs text-[--ink-dim]">{dhikr.meaning} — {dhikr.effect} (≈{dhikr.fTheta} Hz)</p>

      {/* دائرة التسبيح */}
      <button
        onPointerUp={() => fire()}
        className="group relative block touch-pan-y select-none outline-none"
        aria-label={`سَبِّح: ${dhikr.text}`}
        style={{ WebkitTapHighlightColor: 'transparent' }}
      >
        <svg viewBox="0 0 280 280" className="-rotate-90 h-auto w-[min(280px,76vw)]">
          {/* الحلقة الخلفية */}
          <circle cx="140" cy="140" r={R} fill="none" stroke="rgba(252,225,182,0.08)" strokeWidth="3" />
          {/* حلقة التقدم */}
          <circle
            cx="140"
            cy="140"
            r={R}
            fill="none"
            stroke="#d4b67e"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC * (1 - progress)}
            style={{ transition: 'stroke-dashoffset 0.25s ease-out', filter: 'drop-shadow(0 0 6px rgba(212,182,126,0.5))' }}
          />
        </svg>

        {/* جسم الدائرة */}
        <div className="absolute inset-[14px] rounded-full border border-[#fce1b6]/10 bg-[#101e2c]/60 backdrop-blur-sm transition-transform duration-150 group-active:scale-[0.985]" />

        {/* تموجات اللمس */}
        {ripples.map((id) => (
          <span
            key={id}
            className="ripple-ring pointer-events-none absolute inset-[14px] rounded-full border border-[#d4b67e]/60"
          />
        ))}

        {/* المحتوى */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 px-6 sm:gap-2 sm:px-8">
          <span className="font-display text-2xl leading-snug sm:text-4xl text-[#fce1b6]">{dhikr.text}</span>
          <span className="font-ui text-5xl font-semibold sm:text-6xl tabular-nums text-[#f2ede2]">
            {arNum(count)}
          </span>
          <span className="text-xs tracking-widest text-[--ink-dim]">
            من {arNum(dhikr.target)} {rounds > 0 && `· الجولة ${arNum(rounds + 1)}`}
          </span>
        </div>
      </button>

      <div className="flex items-center gap-3 text-xs text-[--ink-faint]"><span>المس الدائرة أو اضغط مسطرة المسافة</span><label className="flex items-center gap-2">العدد<input type="number" min={1} value={dhikr.target} onChange={(e) => onTarget(Math.max(1, +e.target.value || 1))} className="w-20 rounded border hairline bg-transparent px-2 py-1 text-[--ink]" /></label></div>
    </section>
  )
}
